---
name: Feature Request
about: Suggest a new feature or enhancement
labels: feature
---

### Summary
Describe the feature you want.

### Motivation
Why would this be useful?

### Proposed Implementation
How you think this could work.

### Related Components
- [ ] Hyprland
- [ ] Waybar
- [ ] Rofi
- [ ] GUI/TUI
- [ ] Other:

