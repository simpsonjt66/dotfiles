---
name: Bug Report
about: Report something that isn't working
labels: bug
---

### Description
A clear and concise description of the issue.

### Steps to Reproduce
1. 
2. 
3. 

### Expected Behavior
What you expected to happen.

### System Info
- Hyprland version:
- Wayland compositor:
- Distro:
- Logs (if relevant):

